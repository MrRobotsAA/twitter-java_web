package sdut.twitter.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import sdut.twitter.dao.*;
import sdut.twitter.model.*;
 
public class MyFilterLogin implements Filter {
 
    public MyFilterLogin() {
       
    }
 
	public void destroy() {
		 
	}
 
	public void doFilter(ServletRequest req, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		Cookie [] coo =  request.getCookies();
		String autologin = null;
		//System.out.println("ppppds");
		for(int i=0;coo!=null&&i<coo.length;i++) {
			if("auto".equals(coo[i].getName())) {
				autologin = coo[i].getValue();
			}
		}
		if(autologin!=null) {
			String[] parts = autologin.split("-");
			String username = parts[0];
			String password = parts[1];
			try {
				//User use = UserDB.findUser(username);
				Admins admin = QadminDao.findAdmin(username);
				if(admin!=null&&admin.getApwd().equals(password)) {
					//User user = new User();
					Admins ad = new Admins();
					ad.setAname(username);
					ad.setApwd(username);
					request.getSession().setAttribute("admin", ad);
				}
			} catch (SQLException e) {
				 
				e.printStackTrace();
			}
			
		}
		chain.doFilter(request, response);
	}

	 
	public void init(FilterConfig fConfig) throws ServletException {
		 
	}

}
