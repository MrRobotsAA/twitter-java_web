package sdut.twitter.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import sdut.twitter.dao.MessageDao;
import sdut.twitter.model.Messageall;
import sdut.twitter.model.Users;
import sdut.twitter.model.Usersall;
import sdut.twitter.util.Times;

/**
 * Servlet implementation class MessageServlet
 */
@WebServlet("/message.do")
public class MessageServlet extends HttpServlet {
	static MessageDao messageDao = new MessageDao();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String method = request.getParameter("method");
		if ("liebiao".equals(method)) {
			toGetLieBiao(request, response);
		}
		if ("msg".equals(method)) {
			toGetMsg(request, response);
		}
		if ("addmsg".equals(method)) {
			toAddMsg(request, response);
		}
		if ("shuaxin".equals(method)) {
			toShuaxinMsg(request, response);
		}
		if ("hasnew".equals(method)) {
			toHasNew(request, response);
		}

		if ("addfriend".equals(method)) {
			toAddFriend(request, response);
		}
		if ("del".equals(method)) {
			toDel(request, response);
		}
		if ("m".equals(method)) {
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
	}

	//删除朋友(会话)
	private void toDel(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		int fuid = user.getUid();
		String suid = request.getParameter("uid");
		messageDao.delFriend(fuid, suid);
		response.getWriter().print("success");
	}

	//添加朋友
	private void toAddFriend(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		int fuid = user.getUid();
		List<Usersall> usersalls = messageDao.addFriend(fuid);
		JsonConfig config = new JsonConfig();
		config.setExcludes(new String[] { "upwd" });//setExcludes过滤不需要转换的属性
		//json序列化 
		JSONArray array = JSONArray.fromObject(usersalls, config);
		response.getWriter().print(array.toString());
	}
  //main.jsp查询未读消息
	private void toHasNew(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		if(user==null) {
			return;
		}
		int fuid = user.getUid();
		int n = messageDao.hasNew(fuid);
		response.getWriter().print(n);
	}

	//刷新会话信息列表(晚于某条消息的)
	private void toShuaxinMsg(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String suid = request.getParameter("uid");
		String mid = request.getParameter("mid");
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		if(user==null) {
			return;
		}
		int fuid = user.getUid();
		if(user==null) {
			return;
		}
		List<Messageall> list = messageDao.shuaXin(fuid, mid, suid);
		if (list != null) {
			messageDao.toRead(fuid, suid);
			JsonConfig config = new JsonConfig();
			config.setExcludes(new String[] { "mtime" });
			JSONArray jsonArray = JSONArray.fromObject(list, config);
			response.getWriter().print(jsonArray.toString());
		}
	}

	//添加信息
	private void toAddMsg(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String mcontent = request.getParameter("mcontent");
		String suid = request.getParameter("uid");
		if (mcontent == null || "".equals(mcontent.trim())) {
			return;
		}
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		int fuid = user.getUid();
		Timestamp mtime = Times.getSystemTime();
		int n = messageDao.addMsg(fuid, Integer.parseInt(suid), mcontent, mtime, 0);
		if (n > 0) {
			response.getWriter().print("ok");
		}
	}
    //获取消息
	private void toGetMsg(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String suid = request.getParameter("uid");
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		int fuid = user.getUid();
		List<Messageall> list = messageDao.findByTwoId(suid, fuid);
		if (list != null) {
			messageDao.toRead(fuid, suid);
			JsonConfig config = new JsonConfig();
			config.setExcludes(new String[] { "mtime" });
			JSONArray jsonArray = JSONArray.fromObject(list, config);
			response.getWriter().print(jsonArray.toString());
		}
	}

	//获得最后一条消息列表
	private void toGetLieBiao(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		Users user = (Users) session.getAttribute("user");
		
		if(user==null)return ;
		int uid = user.getUid();

		List<Messageall> listF = messageDao.findById(uid, 1);//该账号发送的所有消息
		List<Messageall> listS = messageDao.findById(uid, 2);//该账号接受的所有消息
	
		int num = 0;

		int fSize = listF.size();
		int sSize = listS.size();

		if (fSize != 0 && sSize == 0) {
			listS = listF;
		} else {
			if (fSize < sSize) {  //比较谁大谁小  小的加到大的里面,效率比较高
				for (int i = 0; i < fSize; i++) {
					num = 0;
					for (int j = 0; j < sSize; j++) {
						if (listF.get(i).getSuid() != listS.get(j).getFuid()) {
							num++;
						}
						if (listF.get(i).getSuid() == listS.get(j).getFuid()) {
							if (listS.get(j).getMtime().before(listF.get(i).getMtime())) {
								listS.set(j, listF.get(i));  //否则按时间更新最后一条信息
							}
						}
						if (num == sSize) {
							listS.add(listF.get(i));//当 我当前发送的消息的接收者在 发送给我的发送者列表中不存在时,把我发送的信息当作是我接受的消息列表
						}
					}
				}
			} else {
				for (int i = 0; i < sSize; i++) {
					num = 0;
					for (int j = 0; j < fSize; j++) {
						if (listS.get(i).getFuid() != listF.get(j).getSuid()) {
							num++;
						}
						if (listS.get(i).getFuid() == listF.get(j).getSuid()) {
							if (listF.get(j).getMtime().before(listS.get(i).getMtime())) {
								listF.set(j, listS.get(i));
							}
						}
						if (num == fSize) {
							listF.add(listS.get(i));
						}
					}
				}
				listS = listF;
			}
		}
		Collections.sort(listS, (o1, o2) -> {
			return o2.getMtime().compareTo(o1.getMtime());
		});

		for (Messageall messageall : listS) {
			formatDate(messageall, messageall.getMtime());
		}
		JsonConfig config = new JsonConfig();
		config.setExcludes(new String[] { "mtime" });
		JSONArray jsonArray = JSONArray.fromObject(listS, config);
		response.getWriter().print(jsonArray.toString());
	}

	//  自定义格式化时间
	public void formatDate(Messageall messageall, Timestamp ttime) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yy-MM-dd");

		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);

		String nowyear = year + "-01-01 00:00:00";
		Timestamp yeardate = Timestamp.valueOf(nowyear);

		if (ttime.after(yeardate)) {
			messageall.setTime(sdf.format(ttime));
		} else {
			messageall.setTime(sdf2.format(ttime));
		}
	}

}
