package sdut.twitter.servlet;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sdut.twitter.dao.AdloginDao;
import sdut.twitter.dao.AdminsDao;
import sdut.twitter.dao.SigninDao;
import sdut.twitter.dao.TweetsDao;
import sdut.twitter.dao.UsersDao;
import sdut.twitter.dao.UsersinfoDao;
import sdut.twitter.model.Adlogin;
import sdut.twitter.model.Admins;
import sdut.twitter.service.QadminService;
import sdut.twitter.util.Md5Util;
import sdut.twitter.util.Times;

/**
 * Servlet implementation class QadminServlet
 */
@WebServlet("/qadmin.do")
public class QadminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	private AdminsDao adminsDao = new AdminsDao();          //访问Dao层数据库
	private AdloginDao adloginDao = new AdloginDao();       
	private TweetsDao tweetsDao = new TweetsDao();
	private UsersDao usersDao = new UsersDao();
	private UsersinfoDao usersinfoDao = new UsersinfoDao();
	private SigninDao signinDao = new SigninDao();
   /* public QadminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }*/

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");      //utf-8
		String method = request.getParameter("method");          //获取request域中的method
		if ("checklogin".equals(method)) {
			              
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			Admins value = new Admins();
			value.setAname(request.getParameter("username"));
			value.setApwd(Md5Util.getMd5(request.getParameter("password")));  
			try
			{
				Admins admin = QadminService.login(value);
				if (admin == null) {
					response.sendRedirect("backend.jsp");
					return;
				}
				else if(!admin.getApwd().equals(value.getApwd()))
				{
					response.sendRedirect("backend.jsp");
					return;
				}
				HttpSession session = request.getSession();      //  检查是否存在session，如果没有 在域中添加一个session
				session.setAttribute("admin", admin);            //  admin属性值，付给admin名字。
				Cookie coo = new Cookie("auto",value.getAname()+"-"+value.getApwd());
				coo.setMaxAge(60*3);
				coo.setPath(request.getContextPath());
				response.addCookie(coo);
				doAddLogin(request, response);    
			}catch(Exception e) {
		}
			
		}
	}
	private void doAddLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		Admins admin = (Admins) session.getAttribute("admin");        //获取session值，返回值为admins对象
		if (admin == null) {
			response.sendRedirect("backend.jsp");                    //如果为空，则返回当前界面
			return;
		}
		int aid = admin.getAid();
		Timestamp aditime = Times.getSystemTime();
		int m = adloginDao.addUp(aid, aditime);                 
		if (m > 0) {
			Adlogin adlogin = adloginDao.selSignal(aid, aditime);
			if (adlogin == null) {
				response.sendRedirect("backend.jsp");
				return;
			}
			int adid = adlogin.getAdid();
			adminsDao.updateOnline(1, aid);
			session.setAttribute("adid", adid);
			response.sendRedirect("page.jsp");
		}
	}
	
}
