package sdut.twitter.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import sdut.twitter.dao.ForwardsDao;
import sdut.twitter.dao.NotificationDao;
import sdut.twitter.dao.TweetsDao;
import sdut.twitter.dao.UsersinfoDao;
import sdut.twitter.model.Notification;
import sdut.twitter.model.Users;
import sdut.twitter.model.Usersall;
import sdut.twitter.model.Utweets;

@WebServlet("/notify.do")
public class NotificationServlet extends HttpServlet {
	private NotificationDao notificationDao = new NotificationDao();
	private UsersinfoDao usersinfoDao = new UsersinfoDao();
	private TweetsDao tweetsDao = new TweetsDao();
	private ForwardsDao forwardsDao = new ForwardsDao();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response){
	
	}

}
