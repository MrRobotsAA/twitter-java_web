package sdut.twitter.util;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class C3p0Utils{
  public static ComboPooledDataSource ds;
  static {
	  ds = new ComboPooledDataSource();
  }
  public static ComboPooledDataSource getDataSource(){
	  
	  return ds;
  }
  public static void main(String[] args) {
	System.out.println(ds);
  }
}
