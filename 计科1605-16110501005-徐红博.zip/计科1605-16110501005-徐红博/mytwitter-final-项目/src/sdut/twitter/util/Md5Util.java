package sdut.twitter.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5Util {
	public static String getMd5(String plainText) {
		try {
			plainText = "dgdfgkpg$%^@#$@$#%@f" + plainText;
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(plainText.getBytes());// 通过使用 update 方法处理数据,使指定的 byte数组更新摘要
			byte b[] = md.digest();// 获得密文完成哈希计算,产生128 位的长整数
			int i;
			StringBuffer buf = new StringBuffer("");
			for (int offset = 0; offset < b.length; offset++) {
				i = b[offset];
				if (i < 0)
					i += 256;
				if (i < 16)
					buf.append("0");
				buf.append(Integer.toHexString(i));
			}
			 //32位加密  
            //return buf.toString();  
            // 16位的加密  
            //return buf.toString().substring(8, 24);  
			return buf.toString().substring(8, 24);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}
}
