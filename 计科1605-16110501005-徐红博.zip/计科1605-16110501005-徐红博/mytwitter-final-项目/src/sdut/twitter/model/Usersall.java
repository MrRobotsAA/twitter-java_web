package sdut.twitter.model;

import java.sql.Timestamp;

public class Usersall {
	private int uid;
	private String uname;
	private String upwd;
	private String urealname;
	private String uaite;
	private int ustate;
	private Timestamp utime;
	private int uonline;
	private String uaddress;
	private String uabout;
	private Timestamp udate;
	private String ulogo;
	private String ubg;
	private int ufans;
	private int utweet;
	private int ufollow;
	private String ucolor;
	private int guanzhu;
	private Timestamp lastTime;

	public Timestamp getLastTime() {
		return lastTime;
	}

	public void setLastTime(Timestamp lastTime) {
		this.lastTime = lastTime;
	}

	public int getGuanzhu() {
		return guanzhu;
	}

	public void setGuanzhu(int guanzhu) {
		this.guanzhu = guanzhu;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getUrealname() {
		return urealname;
	}

	public void setUrealname(String urealname) {
		this.urealname = urealname;
	}

	public String getUaite() {
		return uaite;
	}

	public void setUaite(String uaite) {
		this.uaite = uaite;
	}

	public int getUstate() {
		return ustate;
	}

	public void setUstate(int ustate) {
		this.ustate = ustate;
	}

	public Timestamp getUtime() {
		return utime;
	}

	public void setUtime(Timestamp utime) {
		this.utime = utime;
	}

	public int getUonline() {
		return uonline;
	}

	public void setUonline(int uonline) {
		this.uonline = uonline;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	public String getUabout() {
		return uabout;
	}

	public void setUabout(String uabout) {
		this.uabout = uabout;
	}

	public Timestamp getUdate() {
		return udate;
	}

	public void setUdate(Timestamp udate) {
		this.udate = udate;
	}

	public String getUlogo() {
		return ulogo;
	}

	public void setUlogo(String ulogo) {
		this.ulogo = ulogo;
	}

	public String getUbg() {
		return ubg;
	}

	public void setUbg(String ubg) {
		this.ubg = ubg;
	}

	public int getUfans() {
		return ufans;
	}

	public void setUfans(int ufans) {
		this.ufans = ufans;
	}

	public int getUtweet() {
		return utweet;
	}

	public void setUtweet(int utweet) {
		this.utweet = utweet;
	}

	public int getUfollow() {
		return ufollow;
	}

	public void setUfollow(int ufollow) {
		this.ufollow = ufollow;
	}

	public String getUcolor() {
		return ucolor;
	}

	public void setUcolor(String ucolor) {
		this.ucolor = ucolor;
	}

}
