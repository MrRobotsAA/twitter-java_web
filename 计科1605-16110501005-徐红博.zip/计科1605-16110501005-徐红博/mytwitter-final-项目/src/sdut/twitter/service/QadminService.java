package sdut.twitter.service;

import java.sql.SQLException;

import sdut.twitter.dao.QadminDao;
import sdut.twitter.model.Admins;;
public class QadminService {

	public static Admins login(Admins admin) throws SQLException{
		
		Admins admin1 = QadminDao.findAdmin(admin.getAname());
		return admin1;
	}
}
