package sdut.twitter.service;

public class AdminException extends Exception{

	public AdminException() {
		super();
		 
	}
 
	public AdminException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		 
	}

	public AdminException(String arg0) {
		super(arg0);
		 
	}

	public AdminException(Throwable arg0) {
		super(arg0);
		 
	}
	
}
