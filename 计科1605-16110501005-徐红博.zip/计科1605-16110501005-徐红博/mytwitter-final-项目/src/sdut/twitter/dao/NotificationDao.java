package sdut.twitter.dao;

import java.sql.Timestamp;
import java.util.List;

import sdut.twitter.model.Notification;
import sdut.twitter.util.DBUtil;

public class NotificationDao {

}
