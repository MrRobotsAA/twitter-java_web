package sdut.twitter.dao;

import java.sql.Timestamp;
import java.util.List;

import sdut.twitter.model.Messageall;
import sdut.twitter.model.Usersall;
import sdut.twitter.util.DBUtil;

public class MessageDao {
	//删除朋友
	public int delFriend(int fuid, String suid) {
		String sql = "delete from message where ( fuid=? and suid=?) or (fuid=? and suid=?)";
		int n = DBUtil.update(sql, fuid, suid, suid, fuid);
		return n;
	}
   //添加朋友
	public List<Usersall> addFriend(int fuid) {
		String sql = "SELECT * FROM usersall where uid in(select s_uid from concern where f_uid=?);";
		List<Usersall> list = DBUtil.query(Usersall.class, sql, fuid);
		if (list != null)
			return list;
		return null;
	}
  //刷新两人对话的消息列表
	public List<Messageall> shuaXin(int fuid, String mid, String suid) {
		String sql = "select * from messageall where (( fuid=? and suid=?) or (fuid=? and suid=?)) and mid>?";
		List<Messageall> list = DBUtil.query(Messageall.class, sql, fuid, suid, suid, fuid, mid);
		if (list != null)
			return list;
		return null;
	}

	//更新已阅读状态
	public int toRead(int fuid, String suid) {
		String sql = "update message set mread = 1 where  (fuid=? and suid=?) and mread = 0";
		int n = DBUtil.update(sql, suid, fuid);
		return n;
	}

	//查询当前帐号是否有已收到但未阅读的消息
	public int hasNew(int fuid) {
		String sql = "select * from messageall where suid=? and mread=0";
		List<Messageall> list = DBUtil.query(Messageall.class, sql, fuid);
		if (list != null)
			return list.size();
		return 0;
	}

	//添加新消息
	public int addMsg(int fuid, int suid, String mcontent, Timestamp mtime, int mread) {
		String sql = "insert into message(fuid, suid, mcontent, mtime, mread) values(?,?,?,?,?)";
		int n = DBUtil.update(sql, fuid, suid, mcontent, mtime, mread);
		return n;
	}

	//查询消息某特定接收者或发送者的最后一条消息
	public List<Messageall> findById(int uid, int num) {
		String sql = null;
		if (num == 1)
			sql = "select * from messageall where mtime in(select max(mtime) from messageall GROUP BY suid) and fuid = ?";
		else
			sql = "select * from messageall where mtime in(select max(mtime) from messageall GROUP BY fuid) and suid = ?";
		List<Messageall> list = DBUtil.query(Messageall.class, sql, uid);
		if (list != null)
			return list;
		return null;
	}
    //查询某两人的所有的消息
	public List<Messageall> findByTwoId(String fuid, int suid) {
		String sql = "select * from messageall where (fuid=? and suid=?) or (fuid=? and suid=?) ORDER BY mtime";
		List<Messageall> list = DBUtil.query(Messageall.class, sql, fuid, suid, suid, fuid);
		if (list != null)
			return list;
		return null;
	}
}
