package sdut.twitter.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import sdut.twitter.model.Admins;
import sdut.twitter.util.C3p0Utils;;
public class QadminDao {
	
	public static List getAdmins() throws SQLException{
		//查数据库
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		String sql = "select * from admins";
		List list = (List)runner.query(sql, new BeanListHandler(Admins.class));
		
		return list;
	}
	
	public static Admins findAdmin(String name) throws SQLException {
		QueryRunner runner =new QueryRunner(C3p0Utils.getDataSource());
		String sql ="select * from admins where aname=?";
		Admins admin = (Admins) runner.query(sql, new BeanHandler(Admins.class), new Object[] {name});
		return admin;
	}

}
